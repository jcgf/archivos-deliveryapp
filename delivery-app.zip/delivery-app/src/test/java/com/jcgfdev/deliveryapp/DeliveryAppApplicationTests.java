package com.jcgfdev.deliveryapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
